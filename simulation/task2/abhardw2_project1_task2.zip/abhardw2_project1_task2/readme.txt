Simulation Project
Task - 2 

Name: Aditya Bhardwaj
Unity ID: abhardw2

## Instructions to run code:

1. Files are named as:
	* subtask1.py
	* subtask2.py

2. Running subtask1.py:
	* python subtask1.py
	* Generated file after running the code: simulation1.csv
	* Generated text file: simluation1.txt

3. Running subtask2.py:
	* python subtask2.py <first-arrival> <clock-count> <inter-arrival> <re-transmit> <service-time> <buffer>
	* Generated file after running the code: Simulation2.csv 
	* Generated text file: simulation2.txt

